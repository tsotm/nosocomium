package com.nosocomium.service;

import com.nosocomium.pojo.pharmacy;
import com.nosocomium.pojo.purchase;
import com.nosocomium.pojo.sales;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

@Service
public class PurchaseService {
    private static Logger logger= LoggerFactory.getLogger(PurchaseService.class);
    @Autowired
    MongoTemplate mongoTemplate;


    public purchase getPurchaseById(Integer CID) throws Exception {
        Query query = new Query(Criteria.where("CID").is(CID));
        purchase purchase = mongoTemplate.findOne(query, purchase.class);
        if (purchase == null || purchase.getCID() == null) {
            throw new Exception("该订单不存在");
        }
        return purchase;
    }

    public void addPurchase(purchase purchase) throws Exception {
        Query addquery = new Query(Criteria.where("CID").is(purchase.getCID()));
        purchase existingPurchase = mongoTemplate.findOne(addquery, purchase.class);
        Query query2 = new Query(Criteria.where("PID").is(purchase.getPID()));
        pharmacy existingPurchase2 = mongoTemplate.findOne(query2, pharmacy.class);
        if (purchase.getCID() == 0) {
            throw new Exception("订单编号不能为0");
        }
        if (existingPurchase != null) {
            throw new Exception("订单已存在");
        }
        if (purchase.getPID() == 0) {
            throw new Exception("药品编号不能为空");
        }
        if(existingPurchase2 ==null){
            throw new Exception("该药品不存在");
        }
        if (purchase.getPquantity() == 0) {
            throw new Exception("采购药品价格不能为0");
        }

        mongoTemplate.insert(purchase, "purchase");
    }


    public boolean deletePurchaseById(Integer CID) throws Exception {
        Query query = new Query(Criteria.where("CID").is(CID));
        if (query ==null){
            throw new Exception("订单不存在");
        }
        mongoTemplate.remove(query, purchase.class,"purchase");
        return  true;
    }

    public void updatePurchase(purchase purchase) throws Exception {

        Query query = new Query(Criteria.where("CID").is(purchase.getCID()));
        purchase existingPurchase = mongoTemplate.findOne(query, purchase.class);
        Query query2 = new Query(Criteria.where("PID").is(purchase.getPID()));
        pharmacy existingPurchase2 = mongoTemplate.findOne(query2, pharmacy.class);
        if (existingPurchase == null) {
            throw new Exception("订单不存在");
        }
        if (purchase.getPID() == 0) {
            throw new Exception("药品编号不能为0");
        }
        if(existingPurchase2 ==null){
            throw new Exception("该药品不存在");
        }
        System.out.println(existingPurchase2);
        if (purchase.getPquantity() == 0) {
            throw new Exception("采购数量不能为0");
        }
        Update update = new Update();
        update.set("PID", purchase.getPID());
        update.set("Pquantity",purchase.getPquantity());
        update.set("PData",new Date());
        mongoTemplate.updateFirst(query, update, purchase.class);
    }



    public List<purchase> getAllpurchase()
    {
        List<purchase>list=mongoTemplate.findAll(purchase.class,"purchase");
        return  list;
    }

}
