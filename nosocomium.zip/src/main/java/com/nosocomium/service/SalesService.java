package com.nosocomium.service;

import com.nosocomium.pojo.pharmacy;
import com.nosocomium.pojo.purchase;
import com.nosocomium.pojo.sales;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class SalesService {
    private static Logger logger= LoggerFactory.getLogger(SalesService.class);
    @Autowired
    MongoTemplate mongoTemplate;

    public sales getSalesById(Integer SID) throws Exception {
        Query query = new Query(Criteria.where("SID").is(SID));
        sales sales = mongoTemplate.findOne(query, sales.class);
        if (sales == null || sales.getSID() == null) {
            throw new Exception("该订单不存在");
        }
        return sales;
    }

    public void addSales(sales sales) throws Exception {
        Query addquery = new Query(Criteria.where("SID").is(sales.getSID()));
        sales existingPurchase = mongoTemplate.findOne(addquery, sales.class);
        Query query2 = new Query(Criteria.where("PID").is(sales.getPID()));
        pharmacy existingPurchase2 = mongoTemplate.findOne(query2, pharmacy.class);
        if (sales.getSID() == 0) {
            throw new Exception("订单编号不能为0");
        }
        if (existingPurchase != null) {
            throw new Exception("订单已存在");
        }
        if (sales.getPID() == 0) {
            throw new Exception("药品编号不能为空");
        }
        if(existingPurchase2 ==null){
            throw new Exception("该药品不存在");
        }
        if (sales.getSquantity() == 0) {
            throw new Exception("销售数量不能为0");
        }

        mongoTemplate.insert(sales, "sales");
    }


    public boolean deleteSalesById(Integer SID) throws Exception {
        Query query = new Query(Criteria.where("SID").is(SID));
        if (query ==null){
            throw new Exception("订单不存在");
        }
        mongoTemplate.remove(query, sales.class,"sales");
        return  true;
    }

    public void updateSales(sales sales) throws Exception {

        Query query = new Query(Criteria.where("SID").is(sales.getSID()));
        sales existingPurchase = mongoTemplate.findOne(query, sales.class);
        Query query2 = new Query(Criteria.where("PID").is(sales.getPID()));
        pharmacy existingPurchase2 = mongoTemplate.findOne(query2, pharmacy.class);
        if (existingPurchase == null) {
            throw new Exception("订单不存在");
        }
        if (sales.getPID() == 0) {
            throw new Exception("药品编号不能为0");
        }
        if(existingPurchase2 ==null){
            throw new Exception("该药品不存在");
        }
        System.out.println(existingPurchase2);
        if (sales.getSquantity() == 0) {
            throw new Exception("销售数量不能为0");
        }
        Update update = new Update();
        update.set("PID", sales.getPID());
        update.set("Squantity",sales.getSquantity());
        update.set("SDate",new Date());
        mongoTemplate.updateFirst(query, update, sales.class);
    }



    public List<sales> getAllsales()
    {
        List<sales>list=mongoTemplate.findAll(sales.class,"sales");
        return  list;
    }

}
