package com.nosocomium.service;

import com.nosocomium.pojo.pharmacy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PharmacyService {
    private static Logger logger= LoggerFactory.getLogger(PharmacyService.class);
    @Autowired
    MongoTemplate mongoTemplate;

    public pharmacy getPharmacyById(Integer PID) throws Exception {
        Query query = new Query(Criteria.where("PID").is(PID));
        pharmacy pharmacy=mongoTemplate.findOne(query, pharmacy.class);
        if (pharmacy == null || pharmacy.getPID() == null){
            throw new Exception("该商品不存在");
        }
        return  pharmacy;
    }

    public void addPharmacy(pharmacy pharmacy) throws Exception {
        Query addquery = new Query(Criteria.where("PID").is(pharmacy.getPID()));
        pharmacy existingPharmacy = mongoTemplate.findOne(addquery, pharmacy.class);
        if (pharmacy.getPID() == 0) {
            throw new Exception("药品编号不能为0");
        }
        if (existingPharmacy != null) {
            throw new Exception("药品已存在");
        }
        if (pharmacy.getPName() == null || pharmacy.getPName().isEmpty()) {
            throw new Exception("药品名称不能为空");
        }
        if (pharmacy.getPPrice() == 0) {
            throw new Exception("采购药品价格不能为0");
        }
        if (pharmacy.getSPrice() == 0) {
            throw new Exception("销售药品价格不能为0");
        }
        mongoTemplate.insert(pharmacy, "pharmacy");
    }


    public boolean deletePharmacyById(Integer PID) throws Exception {
        System.out.println(PID);
        Query query = new Query(Criteria.where("PID").is(PID));
        if (query ==null){
            throw new Exception("药品不存在");
        }
        System.out.println("要删除的药品ID：" + query);
        mongoTemplate.remove(query, pharmacy.class,"pharmacy");
        System.out.println("删除药品成功：" + query);
        return  true;
    }

    public void updatePharmacy(pharmacy pharmacy) throws Exception {

        Query query = new Query(Criteria.where("PID").is(pharmacy.getPID()));
        System.out.println(query);
        pharmacy existingPharmacy = mongoTemplate.findOne(query, pharmacy.class);
        if (existingPharmacy == null) {
            throw new Exception("药品不存在");
        }
        if (pharmacy.getPName() == null || pharmacy.getPName().isEmpty()) {
            throw new Exception("药品名称不能为空");
        }
        if (pharmacy.getPPrice() == 0) {
            throw new Exception("采购药品价格不能为0");
        }
        if (pharmacy.getSPrice() == 0) {
            throw new Exception("销售药品价格不能为0");
        }
        Update update = new Update();
        update.set("PName", pharmacy.getPName());
        update.set("PPrice", pharmacy.getPPrice());
        update.set("SPrice", pharmacy.getSPrice());
        mongoTemplate.updateFirst(query, update, pharmacy.class);
    }



    public List<pharmacy> getAllpharmacy()
    {
        List<pharmacy>list=mongoTemplate.findAll(pharmacy.class,"pharmacy");
        return  list;
    }
}
