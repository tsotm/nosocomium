package com.nosocomium;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NosocomiumApplication {

    public static void main(String[] args) {
        SpringApplication.run(NosocomiumApplication.class, args);
    }

}
