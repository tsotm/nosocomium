package com.nosocomium.pojo;

public class pharmacy {
    private Integer PID;//药品编号
    private String PName;//药品名称
    private Integer inventory;//药品库存
    private Integer PPrice;//采购价格
    private Integer SPrice;//销售价格
    private Integer earnings;//药品收益

    public pharmacy() {}

    public pharmacy(Integer PID, String PName, Integer inventory, Integer PPrice, Integer SPrice, Integer earnings) {
        this.PID = PID;
        this.PName = PName;
        this.inventory = inventory;
        this.PPrice = PPrice;
        this.SPrice = SPrice;
        this.earnings = earnings;
    }

    @Override
    public String toString() {
        return "pharmacy{" +
                "PID=" + PID +
                ", PName='" + PName + '\'' +
                ", inventory=" + inventory +
                ", PPrice=" + PPrice +
                ", SPrice=" + SPrice +
                ", earnings=" + earnings +
                '}';
    }

    public Integer getPID() {
        return PID;
    }

    public void setPID(Integer PID) {
        this.PID = PID;
    }

    public String getPName() {
        return PName;
    }

    public void setPName(String PName) {
        this.PName = PName;
    }

    public Integer getInventory() {
        return inventory;
    }

    public void setInventory(Integer inventory) {
        this.inventory = inventory;
    }

    public Integer getPPrice() {
        return PPrice;
    }

    public void setPPrice(Integer PPrice) {
        this.PPrice = PPrice;
    }

    public Integer getSPrice() {
        return SPrice;
    }

    public void setSPrice(Integer SPrice) {
        this.SPrice = SPrice;
    }

    public Integer getEarnings() {
        return earnings;
    }

    public void setEarnings(Integer earnings) {
        this.earnings = earnings;
    }
}
