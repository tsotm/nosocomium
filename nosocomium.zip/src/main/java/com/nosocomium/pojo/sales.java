package com.nosocomium.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.xml.crypto.Data;
import java.util.Date;
import java.util.List;

public class sales {
    private Integer SID;//销售单号
    private Integer PID;//药品id
    private Date SDate;//销售时间
    private Integer Squantity;//销售数量
    private Integer Sexpense;//销售费用

    public sales() {
    }

    public sales(Integer SID, Integer PID, Date SDate, Integer squantity, Integer sexpense) {
        this.SID = SID;
        this.PID = PID;
        this.SDate = SDate;
        Squantity = squantity;
        Sexpense = sexpense;
    }

    @Override
    public String toString() {
        return "sales{" +
                "SID=" + SID +
                ", PID=" + PID +
                ", SDate=" + SDate +
                ", Squantity=" + Squantity +
                ", Sexpense=" + Sexpense +
                '}';
    }

    public Integer getSID() {
        return SID;
    }

    public void setSID(Integer SID) {
        this.SID = SID;
    }

    public Integer getPID() {
        return PID;
    }

    public void setPID(Integer PID) {
        this.PID = PID;
    }

    public Date getSDate() {
        return SDate;
    }

    public void setSDate(Date SDate) {
        this.SDate = SDate;
    }

    public Integer getSquantity() {
        return Squantity;
    }

    public void setSquantity(Integer squantity) {
        Squantity = squantity;
    }

    public Integer getSexpense() {
        return Sexpense;
    }

    public void setSexpense(Integer sexpense) {
        Sexpense = sexpense;
    }
}
