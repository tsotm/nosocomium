package com.nosocomium.pojo;

import javax.xml.crypto.Data;
import java.util.Date;

public class purchase {
    private Integer CID;//采购单号
    private Integer PID;//药品编号
    private Date PDate;//采购时间
    private Integer Pquantity;//采购数量
    private Integer Pexpense;//采购费用

    public purchase(){};

    public purchase(Integer CID, Integer PID, Date PDate, Integer pquantity, Integer pexpense) {
        this.CID = CID;
        this.PID = PID;
        this.PDate = PDate;
        Pquantity = pquantity;
        Pexpense = pexpense;
    }

    @Override
    public String toString() {
        return "purchase{" +
                "CID=" + CID +
                ", PID=" + PID +
                ", PDate=" + PDate +
                ", Pquantity=" + Pquantity +
                ", Pexpense=" + Pexpense +
                '}';
    }

    public Integer getCID() {
        return CID;
    }

    public void setCID(Integer CID) {
        this.CID = CID;
    }

    public Integer getPID() {
        return PID;
    }

    public void setPID(Integer PID) {
        this.PID = PID;
    }

    public Date getPDate() {
        return PDate;
    }

    public void setPDate(Date PDate) {
        this.PDate = PDate;
    }

    public Integer getPquantity() {
        return Pquantity;
    }

    public void setPquantity(Integer pquantity) {
        Pquantity = pquantity;
    }

    public Integer getPexpense() {
        return Pexpense;
    }

    public void setPexpense(Integer pexpense) {
        Pexpense = pexpense;
    }
}
