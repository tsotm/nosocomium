package com.nosocomium.controller;


import com.nosocomium.pojo.pharmacy;
import com.nosocomium.service.PharmacyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class pharmacyController {
    private static Logger logger= LoggerFactory.getLogger(pharmacyController.class);

    @Autowired
    PharmacyService pharmacyService;
    @PostMapping("addpharmacy")
    public String addpharmacy(pharmacy pharmacy)
    {
        try {
            pharmacyService.addPharmacy(pharmacy);
            return "添加成功";
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    @GetMapping("getpharmacybyid")
    public pharmacy getPharmacyById(Integer PID) {
        try {
            pharmacy pharmacy = pharmacyService.getPharmacyById(PID);
            return pharmacy;
        } catch (Exception e) {
            logger.error("获取药品信息失败", e);
            return null;
        }
    }

    //修改商品
    @PostMapping("updatePharmacy")
    @ResponseBody
    public String updataById(Integer PID,String PName,Integer PPrice,Integer SPrice) {

        pharmacy pharmacys = new pharmacy();
        pharmacys.setPID(PID);
        pharmacys.setPName(PName);
        pharmacys.setPPrice(PPrice);
        pharmacys.setSPrice(SPrice);
        System.out.println(pharmacys);
        try {
            pharmacyService.updatePharmacy(pharmacys);
            return "成功";
        } catch (Exception e) {
            logger.error("修改药品信息失败", e);
            return "修改失败：" + e.getMessage();
        }
    }



    //删除商品
    @GetMapping("deletePharmacyByid")
    public String deleteById(Integer PID) {
        System.out.println(PID);
        try {
            pharmacyService.deletePharmacyById(PID);
            return "成功";
        } catch (Exception e) {
            logger.error("修改药品信息失败", e);
            return "修改失败：" + e.getMessage();
        }
    }

    @GetMapping("getallpharmacy")
    public Map<String,Object> getAllPharmacy()
    {
        Map<String,Object>map=new HashMap<>();
        List<pharmacy> list=pharmacyService.getAllpharmacy();
        map.put("code","0");
        map.put("count",list.size());
        map.put("data",list);
        return  map;
    }
}
