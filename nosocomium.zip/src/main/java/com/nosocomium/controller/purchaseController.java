package com.nosocomium.controller;


import com.nosocomium.pojo.pharmacy;
import com.nosocomium.pojo.purchase;
import com.nosocomium.service.PharmacyService;
import com.nosocomium.service.PurchaseService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class purchaseController {
    private static Logger logger= LoggerFactory.getLogger(purchaseController.class);

    @Autowired
    PurchaseService purchaseService;
    @PostMapping("addpurchase")
    public String addpurchase(purchase purchase)
    {
        try {
            purchase.setPDate(new Date());
            purchaseService.addPurchase(purchase);
            return "添加成功";
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    @GetMapping("getpurchasebyid")
    public purchase getPurchaseById(Integer CID) {
        try {
            purchase purchase = purchaseService.getPurchaseById(CID);
            return purchase;
        } catch (Exception e) {
            logger.error("获取采购信息失败", e);
            return null;
        }
    }

    //修改商品
    @PostMapping("updatePurchase")
    @ResponseBody
    public String updataById(Integer CID,Integer PID ,Integer Pquantity) {

        purchase purchase = new purchase();
        purchase.setCID(CID);
        purchase.setPID(PID);
        purchase.setPquantity(Pquantity);

        try {
            purchaseService.updatePurchase(purchase);
            return "成功";
        } catch (Exception e) {
            logger.error("修改采购信息失败", e);
            return "修改失败：" + e.getMessage();
        }
    }



    //删除商品
    @GetMapping("deletePurchaseByid")
    public String deleteById(Integer CID) {
        try {
            purchaseService.deletePurchaseById(CID);
            return "成功";
        } catch (Exception e) {
            logger.error("删除采购信息失败", e);
            return "删除失败：" + e.getMessage();
        }
    }

    @GetMapping("getallpurchase")
    public Map<String,Object> getAllPurchase()
    {
        Map<String,Object>map=new HashMap<>();
        List<purchase> list=purchaseService.getAllpurchase();
        map.put("code","0");
        map.put("count",list.size());
        map.put("data",list);
        return  map;
    }
}
