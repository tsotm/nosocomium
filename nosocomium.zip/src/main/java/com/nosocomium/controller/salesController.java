package com.nosocomium.controller;


import com.nosocomium.pojo.purchase;
import com.nosocomium.pojo.sales;
import com.nosocomium.service.SalesService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class salesController {
    private static Logger logger= LoggerFactory.getLogger(salesController.class);

    @Autowired
    SalesService salesService;
    @PostMapping("addsales")
    public String addsales(sales sales)
    {
        try {
            sales.setSDate(new Date());
            salesService.addSales(sales);
            return "添加成功";
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    @GetMapping("getsalesbyid")
    public sales getPurchaseById(Integer SID) {
        try {
            sales sales = salesService.getSalesById(SID);
            return sales;
        } catch (Exception e) {
            logger.error("获取销售信息失败", e);
            return null;
        }
    }

    //修改商品
    @PostMapping("updateSales")
    @ResponseBody
    public String updataById(Integer SID,Integer PID ,Integer Squantity) {

        sales sales = new sales();
        sales.setSID(SID);
        sales.setPID(PID);
        sales.setSquantity(Squantity);

        try {
            salesService.updateSales(sales);
            return "成功";
        } catch (Exception e) {
            logger.error("修改销售信息失败", e);
            return "修改失败：" + e.getMessage();
        }
    }



    //删除商品
    @GetMapping("deleteSalesByid")
    public String deleteById(Integer SID) {
        try {
            salesService.deleteSalesById(SID);
            return "成功";
        } catch (Exception e) {
            logger.error("删除销售信息失败", e);
            return "删除失败：" + e.getMessage();
        }
    }

    @GetMapping("getallsales")
    public Map<String,Object> getAllPurchase()
    {
        Map<String,Object>map=new HashMap<>();
        List<sales> list=salesService.getAllsales();
        map.put("code","0");
        map.put("count",list.size());
        map.put("data",list);
        return  map;
    }
}
