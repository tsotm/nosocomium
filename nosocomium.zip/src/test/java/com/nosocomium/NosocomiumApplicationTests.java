package com.nosocomium;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NosocomiumApplicationTests {

    @Test
    void contextLoads() {
    }

}
